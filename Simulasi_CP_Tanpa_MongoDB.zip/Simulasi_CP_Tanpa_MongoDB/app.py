from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

DB = "bank.db"
NETWORK_OK = True

def init_db():
    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS transaksi(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            jumlah INTEGER
        )
    """)

    conn.commit()
    conn.close()

@app.route('/')
def home():

    conn = sqlite3.connect(DB)

    data = conn.execute(
        "SELECT * FROM transaksi ORDER BY id DESC"
    ).fetchall()

    total_transaksi = conn.execute(
        "SELECT COUNT(*) FROM transaksi"
    ).fetchone()[0]

    total_transfer = conn.execute(
        "SELECT COALESCE(SUM(jumlah),0) FROM transaksi"
    ).fetchone()[0]

    conn.close()

    return render_template(
        'index.html',
        data=data,
        network=NETWORK_OK,
        total_transaksi=total_transaksi,
        total_transfer=total_transfer
    )

    return render_template(
        'index.html',
        data=data,
        network=NETWORK_OK
    )

@app.route('/transfer', methods=['POST'])
def transfer():
    global NETWORK_OK

    nama = request.form['nama']
    jumlah = int(request.form['jumlah'])

    if not NETWORK_OK:
        return """
        <html>
        <head>
        <title>Transfer Ditolak</title>
        <style>
        body{
            font-family:Segoe UI;
            background:#ef4444;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            margin:0;
        }
        .card{
            background:white;
            padding:40px;
            border-radius:20px;
            text-align:center;
        }
        a{
            text-decoration:none;
            background:#2563eb;
            color:white;
            padding:10px 15px;
            border-radius:10px;
        }
        </style>
        </head>
        <body>
            <div class="card">
                <h1>❌ Transfer Ditolak</h1>
                <p>Menunggu Sinkronisasi Data (Simulasi CP)</p>
                <br>
                <a href="/">Kembali</a>
            </div>
        </body>
        </html>
        """, 400

    conn = sqlite3.connect(DB)
    conn.execute(
        "INSERT INTO transaksi(nama,jumlah) VALUES(?,?)",
        (nama, jumlah)
    )
    conn.commit()
    conn.close()

    return redirect('/')

@app.route('/disconnect')
def disconnect():
    global NETWORK_OK
    NETWORK_OK = False
    return redirect('/')

@app.route('/connect')
def connect():
    global NETWORK_OK
    NETWORK_OK = True
    return redirect('/')

@app.route('/hapus')
def hapus():
    conn = sqlite3.connect(DB)
    conn.execute("DELETE FROM transaksi")
    conn.commit()
    conn.close()

    return redirect('/')

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)