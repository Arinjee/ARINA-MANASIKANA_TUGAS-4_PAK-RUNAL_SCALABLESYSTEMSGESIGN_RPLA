
SIMULASI CP (Consistency + Partition Tolerance)

Jalankan:
docker compose up --build

Buka:
http://localhost:5000

Demo:
1. Transfer data -> berhasil
2. Klik Simulasi Partition
3. Transfer lagi -> ditolak
4. Menunjukkan sistem mengutamakan konsistensi data (CP)
